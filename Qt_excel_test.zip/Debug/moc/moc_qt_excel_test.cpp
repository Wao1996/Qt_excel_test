/****************************************************************************
** Meta object code from reading C++ file 'qt_excel_test.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../qt_excel_test.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#include <QtCore/QList>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'qt_excel_test.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_Qt_excel_test_t {
    QByteArrayData data[33];
    char stringdata0[583];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_Qt_excel_test_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_Qt_excel_test_t qt_meta_stringdata_Qt_excel_test = {
    {
QT_MOC_LITERAL(0, 0, 13), // "Qt_excel_test"
QT_MOC_LITERAL(1, 14, 15), // "sig_ReadDataDis"
QT_MOC_LITERAL(2, 30, 0), // ""
QT_MOC_LITERAL(3, 31, 8), // "fileName"
QT_MOC_LITERAL(4, 40, 24), // "QList<QList<QVariant> >*"
QT_MOC_LITERAL(5, 65, 4), // "x_y0"
QT_MOC_LITERAL(6, 70, 16), // "sig_WriteDataDis"
QT_MOC_LITERAL(7, 87, 3), // "x_y"
QT_MOC_LITERAL(8, 91, 16), // "on_timer_timeout"
QT_MOC_LITERAL(9, 108, 21), // "on_btnTimerOn_Clicked"
QT_MOC_LITERAL(10, 130, 25), // "on_btnReadDataDis_Clicked"
QT_MOC_LITERAL(11, 156, 21), // "on_btnPlotDis_Clicked"
QT_MOC_LITERAL(12, 178, 25), // "on_btnSaveDataDis_Clicked"
QT_MOC_LITERAL(13, 204, 24), // "on_btnReceiveDis_Clicked"
QT_MOC_LITERAL(14, 229, 20), // "DoubleClickedPlotDis"
QT_MOC_LITERAL(15, 250, 12), // "QMouseEvent*"
QT_MOC_LITERAL(16, 263, 5), // "event"
QT_MOC_LITERAL(17, 269, 26), // "on_btnClearPlotDis_Clicked"
QT_MOC_LITERAL(18, 296, 21), // "contextMenuRequestDis"
QT_MOC_LITERAL(19, 318, 3), // "pos"
QT_MOC_LITERAL(20, 322, 25), // "on_btnReadDataFor_Clicked"
QT_MOC_LITERAL(21, 348, 21), // "on_btnPlotFor_Clicked"
QT_MOC_LITERAL(22, 370, 25), // "on_btnSaveDataFor_Clicked"
QT_MOC_LITERAL(23, 396, 20), // "DoubleClickedPlotFor"
QT_MOC_LITERAL(24, 417, 26), // "on_btnClearPlotFor_Clicked"
QT_MOC_LITERAL(25, 444, 21), // "contextMenuRequestFor"
QT_MOC_LITERAL(26, 466, 22), // "on_act_zoomIn_toggled_"
QT_MOC_LITERAL(27, 489, 4), // "arg1"
QT_MOC_LITERAL(28, 494, 20), // "on_act_move_toggled_"
QT_MOC_LITERAL(29, 515, 16), // "traceGraphSelect"
QT_MOC_LITERAL(30, 532, 21), // "warnWriteExcelIsEmpty"
QT_MOC_LITERAL(31, 554, 14), // "writeExcelDown"
QT_MOC_LITERAL(32, 569, 13) // "readExcelDown"

    },
    "Qt_excel_test\0sig_ReadDataDis\0\0fileName\0"
    "QList<QList<QVariant> >*\0x_y0\0"
    "sig_WriteDataDis\0x_y\0on_timer_timeout\0"
    "on_btnTimerOn_Clicked\0on_btnReadDataDis_Clicked\0"
    "on_btnPlotDis_Clicked\0on_btnSaveDataDis_Clicked\0"
    "on_btnReceiveDis_Clicked\0DoubleClickedPlotDis\0"
    "QMouseEvent*\0event\0on_btnClearPlotDis_Clicked\0"
    "contextMenuRequestDis\0pos\0"
    "on_btnReadDataFor_Clicked\0"
    "on_btnPlotFor_Clicked\0on_btnSaveDataFor_Clicked\0"
    "DoubleClickedPlotFor\0on_btnClearPlotFor_Clicked\0"
    "contextMenuRequestFor\0on_act_zoomIn_toggled_\0"
    "arg1\0on_act_move_toggled_\0traceGraphSelect\0"
    "warnWriteExcelIsEmpty\0writeExcelDown\0"
    "readExcelDown"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Qt_excel_test[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      23,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    2,  129,    2, 0x06 /* Public */,
       6,    2,  134,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       8,    0,  139,    2, 0x08 /* Private */,
       9,    0,  140,    2, 0x08 /* Private */,
      10,    0,  141,    2, 0x08 /* Private */,
      11,    0,  142,    2, 0x08 /* Private */,
      12,    0,  143,    2, 0x08 /* Private */,
      13,    0,  144,    2, 0x08 /* Private */,
      14,    1,  145,    2, 0x08 /* Private */,
      17,    0,  148,    2, 0x08 /* Private */,
      18,    1,  149,    2, 0x08 /* Private */,
      20,    0,  152,    2, 0x08 /* Private */,
      21,    0,  153,    2, 0x08 /* Private */,
      22,    0,  154,    2, 0x08 /* Private */,
      23,    1,  155,    2, 0x08 /* Private */,
      24,    0,  158,    2, 0x08 /* Private */,
      25,    1,  159,    2, 0x08 /* Private */,
      26,    1,  162,    2, 0x08 /* Private */,
      28,    1,  165,    2, 0x08 /* Private */,
      29,    0,  168,    2, 0x08 /* Private */,
      30,    0,  169,    2, 0x08 /* Private */,
      31,    0,  170,    2, 0x08 /* Private */,
      32,    0,  171,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString, 0x80000000 | 4,    3,    5,
    QMetaType::Void, 0x80000000 | 4, QMetaType::QString,    7,    3,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 15,   16,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QPoint,   19,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 15,   16,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QPoint,   19,
    QMetaType::Void, QMetaType::Bool,   27,
    QMetaType::Void, QMetaType::Bool,   27,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void Qt_excel_test::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<Qt_excel_test *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->sig_ReadDataDis((*reinterpret_cast< QString(*)>(_a[1])),(*reinterpret_cast< QList<QList<QVariant> >*(*)>(_a[2]))); break;
        case 1: _t->sig_WriteDataDis((*reinterpret_cast< QList<QList<QVariant> >*(*)>(_a[1])),(*reinterpret_cast< QString(*)>(_a[2]))); break;
        case 2: _t->on_timer_timeout(); break;
        case 3: _t->on_btnTimerOn_Clicked(); break;
        case 4: _t->on_btnReadDataDis_Clicked(); break;
        case 5: _t->on_btnPlotDis_Clicked(); break;
        case 6: _t->on_btnSaveDataDis_Clicked(); break;
        case 7: _t->on_btnReceiveDis_Clicked(); break;
        case 8: _t->DoubleClickedPlotDis((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        case 9: _t->on_btnClearPlotDis_Clicked(); break;
        case 10: _t->contextMenuRequestDis((*reinterpret_cast< QPoint(*)>(_a[1]))); break;
        case 11: _t->on_btnReadDataFor_Clicked(); break;
        case 12: _t->on_btnPlotFor_Clicked(); break;
        case 13: _t->on_btnSaveDataFor_Clicked(); break;
        case 14: _t->DoubleClickedPlotFor((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        case 15: _t->on_btnClearPlotFor_Clicked(); break;
        case 16: _t->contextMenuRequestFor((*reinterpret_cast< QPoint(*)>(_a[1]))); break;
        case 17: _t->on_act_zoomIn_toggled_((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 18: _t->on_act_move_toggled_((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 19: _t->traceGraphSelect(); break;
        case 20: _t->warnWriteExcelIsEmpty(); break;
        case 21: _t->writeExcelDown(); break;
        case 22: _t->readExcelDown(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (Qt_excel_test::*)(QString , QList<QList<QVariant>> * );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Qt_excel_test::sig_ReadDataDis)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (Qt_excel_test::*)(QList<QList<QVariant> > * , QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&Qt_excel_test::sig_WriteDataDis)) {
                *result = 1;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject Qt_excel_test::staticMetaObject = { {
    &QMainWindow::staticMetaObject,
    qt_meta_stringdata_Qt_excel_test.data,
    qt_meta_data_Qt_excel_test,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *Qt_excel_test::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Qt_excel_test::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_Qt_excel_test.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int Qt_excel_test::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 23)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 23;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 23)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 23;
    }
    return _id;
}

// SIGNAL 0
void Qt_excel_test::sig_ReadDataDis(QString _t1, QList<QList<QVariant>> * _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void Qt_excel_test::sig_WriteDataDis(QList<QList<QVariant> > * _t1, QString _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
