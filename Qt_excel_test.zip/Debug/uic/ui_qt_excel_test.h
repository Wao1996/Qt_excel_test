/********************************************************************************
** Form generated from reading UI file 'qt_excel_test.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_QT_EXCEL_TEST_H
#define UI_QT_EXCEL_TEST_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include <qcustomplot.h>

QT_BEGIN_NAMESPACE

class Ui_Qt_excel_testClass
{
public:
    QAction *act_zoomIn;
    QAction *act_move;
    QAction *act_tracer;
    QWidget *centralWidget;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout_5;
    QSpacerItem *horizontalSpacer_7;
    QPushButton *btnTimerOn;
    QSpacerItem *horizontalSpacer_8;
    QHBoxLayout *horizontalLayout_2;
    QSpacerItem *horizontalSpacer_3;
    QLabel *labelDataStatus;
    QSpacerItem *horizontalSpacer_4;
    QLabel *label_time;
    QCustomPlot *widget_displacement;
    QHBoxLayout *horizontalLayout_6;
    QSpacerItem *horizontalSpacer;
    QPushButton *btnOpenDataDis;
    QPushButton *btnPlotDis;
    QPushButton *btnClearPlotDis;
    QPushButton *btnSaveDataDis;
    QSpacerItem *horizontalSpacer_2;
    QHBoxLayout *horizontalLayout_4;
    QSpacerItem *horizontalSpacer_5;
    QHBoxLayout *horizontalLayout_3;
    QLabel *label_X;
    QLineEdit *lineEdit_X;
    QLabel *label_Y;
    QLineEdit *lineEdit_Y;
    QPushButton *btnReceiveDis;
    QSpacerItem *horizontalSpacer_6;
    QCustomPlot *widget_force;
    QHBoxLayout *horizontalLayout;
    QSpacerItem *horizontalSpacer_9;
    QPushButton *btnOpenDataForce;
    QPushButton *btnPlotForce;
    QPushButton *btnClearPlotForce;
    QPushButton *btnSaveDataForce;
    QSpacerItem *horizontalSpacer_10;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *Qt_excel_testClass)
    {
        if (Qt_excel_testClass->objectName().isEmpty())
            Qt_excel_testClass->setObjectName(QString::fromUtf8("Qt_excel_testClass"));
        Qt_excel_testClass->resize(1187, 938);
        act_zoomIn = new QAction(Qt_excel_testClass);
        act_zoomIn->setObjectName(QString::fromUtf8("act_zoomIn"));
        act_zoomIn->setCheckable(true);
        QIcon icon;
        icon.addFile(QString::fromUtf8(":/Qt_excel_test/src/select.png"), QSize(), QIcon::Normal, QIcon::Off);
        act_zoomIn->setIcon(icon);
        act_move = new QAction(Qt_excel_testClass);
        act_move->setObjectName(QString::fromUtf8("act_move"));
        act_move->setCheckable(true);
        QIcon icon1;
        icon1.addFile(QString::fromUtf8(":/Qt_excel_test/src/move.png"), QSize(), QIcon::Normal, QIcon::Off);
        act_move->setIcon(icon1);
        act_tracer = new QAction(Qt_excel_testClass);
        act_tracer->setObjectName(QString::fromUtf8("act_tracer"));
        act_tracer->setCheckable(true);
        QIcon icon2;
        icon2.addFile(QString::fromUtf8(":/Qt_excel_test/src/\346\270\270\346\240\207.png"), QSize(), QIcon::Normal, QIcon::Off);
        act_tracer->setIcon(icon2);
        centralWidget = new QWidget(Qt_excel_testClass);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        verticalLayout = new QVBoxLayout(centralWidget);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setSpacing(6);
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        horizontalSpacer_7 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_5->addItem(horizontalSpacer_7);

        btnTimerOn = new QPushButton(centralWidget);
        btnTimerOn->setObjectName(QString::fromUtf8("btnTimerOn"));

        horizontalLayout_5->addWidget(btnTimerOn);

        horizontalSpacer_8 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_5->addItem(horizontalSpacer_8);


        verticalLayout->addLayout(horizontalLayout_5);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setSpacing(6);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalSpacer_3 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_3);

        labelDataStatus = new QLabel(centralWidget);
        labelDataStatus->setObjectName(QString::fromUtf8("labelDataStatus"));
        labelDataStatus->setMinimumSize(QSize(100, 0));
        labelDataStatus->setMaximumSize(QSize(16777215, 20));

        horizontalLayout_2->addWidget(labelDataStatus);

        horizontalSpacer_4 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_2->addItem(horizontalSpacer_4);


        verticalLayout->addLayout(horizontalLayout_2);

        label_time = new QLabel(centralWidget);
        label_time->setObjectName(QString::fromUtf8("label_time"));
        label_time->setMinimumSize(QSize(100, 0));
        label_time->setMaximumSize(QSize(16777215, 20));

        verticalLayout->addWidget(label_time);

        widget_displacement = new QCustomPlot(centralWidget);
        widget_displacement->setObjectName(QString::fromUtf8("widget_displacement"));
        widget_displacement->setMinimumSize(QSize(700, 300));

        verticalLayout->addWidget(widget_displacement);

        horizontalLayout_6 = new QHBoxLayout();
        horizontalLayout_6->setSpacing(6);
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_6->addItem(horizontalSpacer);

        btnOpenDataDis = new QPushButton(centralWidget);
        btnOpenDataDis->setObjectName(QString::fromUtf8("btnOpenDataDis"));

        horizontalLayout_6->addWidget(btnOpenDataDis);

        btnPlotDis = new QPushButton(centralWidget);
        btnPlotDis->setObjectName(QString::fromUtf8("btnPlotDis"));

        horizontalLayout_6->addWidget(btnPlotDis);

        btnClearPlotDis = new QPushButton(centralWidget);
        btnClearPlotDis->setObjectName(QString::fromUtf8("btnClearPlotDis"));

        horizontalLayout_6->addWidget(btnClearPlotDis);

        btnSaveDataDis = new QPushButton(centralWidget);
        btnSaveDataDis->setObjectName(QString::fromUtf8("btnSaveDataDis"));

        horizontalLayout_6->addWidget(btnSaveDataDis);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_6->addItem(horizontalSpacer_2);


        verticalLayout->addLayout(horizontalLayout_6);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setSpacing(6);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        horizontalSpacer_5 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer_5);

        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setSpacing(6);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        label_X = new QLabel(centralWidget);
        label_X->setObjectName(QString::fromUtf8("label_X"));
        label_X->setMinimumSize(QSize(20, 0));

        horizontalLayout_3->addWidget(label_X);

        lineEdit_X = new QLineEdit(centralWidget);
        lineEdit_X->setObjectName(QString::fromUtf8("lineEdit_X"));
        lineEdit_X->setMinimumSize(QSize(100, 0));

        horizontalLayout_3->addWidget(lineEdit_X);

        label_Y = new QLabel(centralWidget);
        label_Y->setObjectName(QString::fromUtf8("label_Y"));
        label_Y->setMinimumSize(QSize(20, 0));

        horizontalLayout_3->addWidget(label_Y);

        lineEdit_Y = new QLineEdit(centralWidget);
        lineEdit_Y->setObjectName(QString::fromUtf8("lineEdit_Y"));
        lineEdit_Y->setMinimumSize(QSize(100, 0));

        horizontalLayout_3->addWidget(lineEdit_Y);


        horizontalLayout_4->addLayout(horizontalLayout_3);

        btnReceiveDis = new QPushButton(centralWidget);
        btnReceiveDis->setObjectName(QString::fromUtf8("btnReceiveDis"));

        horizontalLayout_4->addWidget(btnReceiveDis);

        horizontalSpacer_6 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer_6);


        verticalLayout->addLayout(horizontalLayout_4);

        widget_force = new QCustomPlot(centralWidget);
        widget_force->setObjectName(QString::fromUtf8("widget_force"));
        widget_force->setMinimumSize(QSize(700, 300));

        verticalLayout->addWidget(widget_force);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalSpacer_9 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_9);

        btnOpenDataForce = new QPushButton(centralWidget);
        btnOpenDataForce->setObjectName(QString::fromUtf8("btnOpenDataForce"));

        horizontalLayout->addWidget(btnOpenDataForce);

        btnPlotForce = new QPushButton(centralWidget);
        btnPlotForce->setObjectName(QString::fromUtf8("btnPlotForce"));

        horizontalLayout->addWidget(btnPlotForce);

        btnClearPlotForce = new QPushButton(centralWidget);
        btnClearPlotForce->setObjectName(QString::fromUtf8("btnClearPlotForce"));

        horizontalLayout->addWidget(btnClearPlotForce);

        btnSaveDataForce = new QPushButton(centralWidget);
        btnSaveDataForce->setObjectName(QString::fromUtf8("btnSaveDataForce"));

        horizontalLayout->addWidget(btnSaveDataForce);

        horizontalSpacer_10 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer_10);


        verticalLayout->addLayout(horizontalLayout);

        Qt_excel_testClass->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(Qt_excel_testClass);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 1187, 26));
        Qt_excel_testClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(Qt_excel_testClass);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        mainToolBar->setToolButtonStyle(Qt::ToolButtonTextUnderIcon);
        Qt_excel_testClass->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(Qt_excel_testClass);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        Qt_excel_testClass->setStatusBar(statusBar);

        mainToolBar->addAction(act_move);
        mainToolBar->addAction(act_zoomIn);
        mainToolBar->addAction(act_tracer);

        retranslateUi(Qt_excel_testClass);

        QMetaObject::connectSlotsByName(Qt_excel_testClass);
    } // setupUi

    void retranslateUi(QMainWindow *Qt_excel_testClass)
    {
        Qt_excel_testClass->setWindowTitle(QApplication::translate("Qt_excel_testClass", "Qt_excel_test", nullptr));
        act_zoomIn->setText(QApplication::translate("Qt_excel_testClass", "\346\241\206\351\200\211\346\224\276\345\244\247", nullptr));
#ifndef QT_NO_TOOLTIP
        act_zoomIn->setToolTip(QApplication::translate("Qt_excel_testClass", "\346\241\206\351\200\211\346\224\276\345\244\247", nullptr));
#endif // QT_NO_TOOLTIP
        act_move->setText(QApplication::translate("Qt_excel_testClass", "\346\213\226\345\212\250", nullptr));
#ifndef QT_NO_TOOLTIP
        act_move->setToolTip(QApplication::translate("Qt_excel_testClass", "\346\213\226\345\212\250", nullptr));
#endif // QT_NO_TOOLTIP
        act_tracer->setText(QApplication::translate("Qt_excel_testClass", "\346\270\270\346\240\207", nullptr));
#ifndef QT_NO_TOOLTIP
        act_tracer->setToolTip(QApplication::translate("Qt_excel_testClass", "\346\270\270\346\240\207", nullptr));
#endif // QT_NO_TOOLTIP
        btnTimerOn->setText(QApplication::translate("Qt_excel_testClass", "\350\256\241\346\227\266\345\231\250\345\274\200\345\247\213", nullptr));
        labelDataStatus->setText(QApplication::translate("Qt_excel_testClass", "\346\226\207\344\273\266\347\212\266\346\200\201", nullptr));
        label_time->setText(QApplication::translate("Qt_excel_testClass", "\346\226\207\344\273\266\350\200\227\346\227\266", nullptr));
        btnOpenDataDis->setText(QApplication::translate("Qt_excel_testClass", "\345\257\274\345\205\245\344\275\215\347\247\273\346\225\260\346\215\256", nullptr));
        btnPlotDis->setText(QApplication::translate("Qt_excel_testClass", "\345\274\200\345\247\213\347\273\230\345\233\276", nullptr));
        btnClearPlotDis->setText(QApplication::translate("Qt_excel_testClass", "\346\270\205\351\231\244\346\233\262\347\272\277", nullptr));
        btnSaveDataDis->setText(QApplication::translate("Qt_excel_testClass", "\344\277\235\345\255\230\346\225\260\346\215\256", nullptr));
        label_X->setText(QApplication::translate("Qt_excel_testClass", "X", nullptr));
        label_Y->setText(QApplication::translate("Qt_excel_testClass", "Y", nullptr));
        btnReceiveDis->setText(QApplication::translate("Qt_excel_testClass", "\346\216\245\346\224\266\344\277\241\345\217\267", nullptr));
        btnOpenDataForce->setText(QApplication::translate("Qt_excel_testClass", "\345\257\274\345\205\245\345\212\233\346\225\260\346\215\256", nullptr));
        btnPlotForce->setText(QApplication::translate("Qt_excel_testClass", "\345\274\200\345\247\213\347\273\230\345\233\276", nullptr));
        btnClearPlotForce->setText(QApplication::translate("Qt_excel_testClass", "\346\270\205\351\231\244\346\233\262\347\272\277", nullptr));
        btnSaveDataForce->setText(QApplication::translate("Qt_excel_testClass", "\344\277\235\345\255\230\346\225\260\346\215\256", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Qt_excel_testClass: public Ui_Qt_excel_testClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_QT_EXCEL_TEST_H
