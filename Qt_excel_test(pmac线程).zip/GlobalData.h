#pragma once
#include <QVariant>
#include <QVector>
class GlobalData
{
public:
	GlobalData();
	~GlobalData();
	static double forceCurr ;
	static double displacementCurr;
	static QVector<double> force;
	static QVector<double> displacement;
	
};

