#include "GlobalData.h"

double GlobalData::forceCurr = 0;
double GlobalData::displacementCurr = 0;
QVector<double> GlobalData::force = QVector<double>();
QVector<double> GlobalData::displacement = QVector<double>();

GlobalData::GlobalData()
{
	
}

GlobalData::~GlobalData()
{
}
