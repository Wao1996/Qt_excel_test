#pragma once

#include <QObject>
#include <QDebug>	
#include <QThread>
#include <QTimer>
#include "pcommDevice.h"

using namespace PCOMMSERVERLib;
class MyPmacThread : public QObject
{
	Q_OBJECT

public:
	MyPmacThread(QObject *parent = nullptr);
	~MyPmacThread();
private:
	QTimer * pmacTimer;//��ʱ��
	double timecount;//��ʱ������ʱ��
	/*Pmac*/
	PCOMMSERVERLib::PmacDevice* Pmac;
	QString pAnswer = "default";
	int hWindow = 0;//������
	int pdwDevice = 0;//�豸��
	int dwDevice = 0;
	bool pbSuccess = false;//�Ƿ�ɹ���־
	//download
	QString PmacfilePath;
	bool pbDownLoadSuccess;

signals:
	void PmacSelect(PmacDevice* Pmac);
public slots:
	void startThread();
	void PmacContact_Thread();
	void ReadPmac_Thread();
	void ClosePmac_Thread();
	void on_timer_timeout(); //��ʱ��������ۺ���
	
};
