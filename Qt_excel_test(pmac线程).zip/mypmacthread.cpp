#include "mypmacthread.h"
#include "GlobalData.h"

MyPmacThread::MyPmacThread(QObject *parent) : QObject(parent)
{
}

MyPmacThread::~MyPmacThread()
{
	Pmac->Close(dwDevice);
}

void MyPmacThread::startThread()
{
	qDebug() << "startThread" << "����Pmac�߳�:" << QThread::currentThreadId();
	/*************��ʱ������ʱ��ģ��***************/
	pmacTimer = new QTimer(this);//��ʱ��
	pmacTimer->setTimerType(Qt::PreciseTimer);
	timecount = 100;
	pmacTimer->setInterval(timecount);//���ö�ʱ���ڣ���λ������

	//��ʱ������
	connect(pmacTimer, &QTimer::timeout, this, &MyPmacThread::on_timer_timeout);
}

void MyPmacThread::PmacContact_Thread()
{
	/*************PMACģ��************************/
	Pmac = new PmacDevice;
	emit PmacSelect(Pmac);
	//Pmac->SelectDevice(hWindow, pdwDevice, pbSuccess);
	//qDebug() << "Select:" << pbSuccess;
	//Pmac->Open(dwDevice, pbSuccess);
	//qDebug() << "open:" << pbSuccess;
}

void MyPmacThread::ReadPmac_Thread()
{
	qDebug() << "ReadPmac_Thread a v s";
	pmacTimer->start();
	Pmac->GetResponse(dwDevice, "enable plc 1", pAnswer);
	Pmac->GetResponse(dwDevice, "&1b1r", pAnswer);
}

void MyPmacThread::ClosePmac_Thread()
{
	pmacTimer->stop();
	Pmac->GetResponse(dwDevice, "m114=0", pAnswer);//1��ʧȥ���ʹ��

}

void MyPmacThread::on_timer_timeout()
{
	/*λ��*/
	Pmac->GetResponse(dwDevice, "M162", pAnswer);//λ��
	GlobalData::displacementCurr = pAnswer.left(pAnswer.length() - 1).toDouble() / 3072 / 8192 * 16;
	GlobalData::displacement.append(GlobalData::displacementCurr);
	/*��*/
	Pmac->GetResponse(dwDevice, "P15", pAnswer);//��
	GlobalData::forceCurr = pAnswer.left(pAnswer.length() - 1).toDouble() *0.15258789;
	GlobalData::force.append(GlobalData::forceCurr);
	qDebug() << "λ����";
}


