/********************************************************************************
** Form generated from reading UI file 'exceldlg.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_EXCELDLG_H
#define UI_EXCELDLG_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QVBoxLayout>

QT_BEGIN_NAMESPACE

class Ui_ExcelDlg
{
public:
    QVBoxLayout *verticalLayout;
    QProgressBar *progressBar;

    void setupUi(QDialog *ExcelDlg)
    {
        if (ExcelDlg->objectName().isEmpty())
            ExcelDlg->setObjectName(QString::fromUtf8("ExcelDlg"));
        ExcelDlg->resize(634, 85);
        verticalLayout = new QVBoxLayout(ExcelDlg);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        progressBar = new QProgressBar(ExcelDlg);
        progressBar->setObjectName(QString::fromUtf8("progressBar"));
        progressBar->setValue(0);

        verticalLayout->addWidget(progressBar);


        retranslateUi(ExcelDlg);

        QMetaObject::connectSlotsByName(ExcelDlg);
    } // setupUi

    void retranslateUi(QDialog *ExcelDlg)
    {
        ExcelDlg->setWindowTitle(QApplication::translate("ExcelDlg", "\346\255\243\345\234\250\345\244\204\347\220\206", nullptr));
    } // retranslateUi

};

namespace Ui {
    class ExcelDlg: public Ui_ExcelDlg {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_EXCELDLG_H
